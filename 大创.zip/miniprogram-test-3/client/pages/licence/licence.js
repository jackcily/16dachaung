// pages/licence/licence.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    casArray: ['食品', '产品抽检', '特殊食品', '相关链接', '广告'],
    casIndex: 0,
    mArray:['食品生产许可获证企业（SC）','食品生产许可获证企业（QS）','食品添加剂生产许可获证企业'],
    mIndex:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  bindCasPickerChange: function (e) {
    console.log('选的是', this.data.casArray[e.detail.value])
    if (e.detail.value == 4) {
      this.setData({ reply: true })
    } else {
      this.setData({ reply: false })
    }
    this.setData({
      casIndex: e.detail.value
    })

  },
  bindPickerChange: function (e) {
    console.log('选的是', this.data.mArray[e.detail.value])
    if (e.detail.value == 3) {
      this.setData({ reply: true })
    } else {
      this.setData({ reply: false })
    }
    this.setData({
      mIndex: e.detail.value
    })

  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})