Page({ 
  gotoHome(){
    wx.redirectTo({ url: '../index/index' });
  },
})