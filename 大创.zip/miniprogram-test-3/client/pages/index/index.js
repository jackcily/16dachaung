var app=getApp()
Page({
  data:{
    show:'',
    imgUrls: [
      "../images/1.png",
      "../images/2.png",
      "../images/3.png",
      "../images/4.png"
    ],
    autoplay: true,
    indicatorDots: true,
    interval: 3000,
    duration: 800
  },
  gotoUser() {
    wx.redirectTo({ url: '../user/user' });
  },
  licence(){
    wx.navigateTo({ url: '../licence/licence' });
  },
  food() {
    wx.navigateTo({ url: '../food/food' });
  },
  bindconnect: function (e) {
    var that = this;
    var formData = e.detail.value.keyword;
    //console.log(formData);
    if(formData)
    {
      wx.request({
        url: 'http://62.234.117.231/hyq.php',  //本地服务器地址
        data: {
          keyword: formData,
        },
        method: 'GET',
        header: {
          'content-type': 'application/json' //默认值
        },
        success: function (res) {
          console.log(typeof(res.data));
          // var m = JSON.parse(res.data);
          // console.log(typeof(m));
          console.log(res.data);
          var data = JSON.stringify(res.data);
          data=encodeURIComponent(data);
          console.log(data);
          wx.navigateTo({
            url: '../searchResult/searchResult?data=' + data,
          })  
        },
        fail: function (res) {
          console.log("失败");
        }
      })
    }
    else{
      wx.showToast({
        title: '输入不能为空',
        icon: 'none',
        duration: 1500
      })
    } 

  },

  scan:function(){
    var _this=this;
    wx.scanCode({
      success: (res) => {
        console.log(res);
      _this.setData({
        show:res.result
      });
      wx.showToast({
        title:'成功',
        icon:'success',
        duration:2000
      });
      },
      fail: (res) => {
        wx.showToast({
          title: '失败',
          icon:'loading',
          duration: 2000
        })
      },
    })
  },
})